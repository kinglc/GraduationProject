package com.king.block.user;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.king.block.Global;
import com.king.block.R;

import java.util.List;

public class FriendAdapter extends ArrayAdapter<Friend>{
    private int resourceId;
    public int selectIndex = -1;
    private ListView mListView;
    private Global global;
    private int prize[]={1,24,50,100,500};
    private int clr[]={R.drawable.note5,
            R.drawable.note4,
            R.drawable.note3,
            R.drawable.note2,
            R.drawable.note1,
            R.drawable.note0};

    private Friend friend;
    private ViewHolder viewHolder;
    public FriendAdapter(Context context,int textViewResourceId,List<Friend> objects){
        super(context,textViewResourceId,objects);
        resourceId=textViewResourceId;
    }

    @Override
    public View getView(int position,View convertView, ViewGroup parent){
        friend = (Friend)getItem(position);
        viewHolder = null;
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_friend, parent, false);
            viewHolder = new ViewHolder();
            initHolder(convertView,viewHolder);

            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.rank.setText(position+1+"");
        viewHolder.name.setText(friend.getName());
        viewHolder.time.setText(friend.getTime());
        viewHolder.avatar.setText(friend.getName().charAt(0)+"");
        int t = this.global.countTime(friend.getTime());
        int pos=0;
        for(;pos<prize.length;pos++){
            if(t<60*prize[pos]) break;
        }
        viewHolder.avatar.setBackgroundResource(clr[pos]);

        switch (position){
            case 0:
                viewHolder.rank.setTextColor(getContext().getColor(R.color.gold));
                viewHolder.time.setTextColor(getContext().getColor(R.color.gold));
                break;
            case 1:viewHolder.rank.setTextColor(getContext().getColor(R.color.silver));
                viewHolder.time.setTextColor(getContext().getColor(R.color.silver));break;
            case 2:viewHolder.rank.setTextColor(getContext().getColor(R.color.copper));
                viewHolder.time.setTextColor(getContext().getColor(R.color.copper));break;
            default:viewHolder.rank.setTextColor(getContext().getColor(R.color.gray));
                viewHolder.time.setTextColor(getContext().getColor(R.color.gray));break;
        }
        return convertView;
    }

    public void setGlobal(Global global) {
        this.global = global;
    }

    private void initHolder(View v, ViewHolder vh){
        vh.rank = (TextView) v.findViewById(R.id.rank);
        vh.name = (TextView) v.findViewById(R.id.name);
        vh.time = (TextView) v.findViewById(R.id.time);
        vh.avatar = (TextView) v.findViewById(R.id.avatar);
    }

    class ViewHolder{
        TextView rank;
        TextView name;
        TextView time;
        TextView avatar;
    }
}